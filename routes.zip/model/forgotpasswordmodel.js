const { DataTypes } = require('sequelize');
const sequelize = require('../util/db');
const { v4: uuidv4 } = require('uuid');

const forgotPassword = sequelize.define('forgotPassword', {
  id: {
    type: DataTypes.UUID,
    primaryKey: true,
    defaultValue: () => uuidv4(),
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
});

module.exports = forgotPassword;

const { DataTypes } = require('sequelize');
const sequelize = require('../util/db');


const Order = sequelize.define('order', {
  // Model attributes are defined here
  order_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
  payment_id: {
    type: DataTypes.STRING,
  },
  payment_sign: {
    type: DataTypes.STRING,
  },
  payment_status:DataTypes.STRING,
  
}, {
  // Other model options go here
});

module.exports=Order;
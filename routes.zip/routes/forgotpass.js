const express = require('express');
const router = express.Router();
const forgotPassController = require('../controllers/forgotpass'); // Import the controller module

// Define your routes using the controller functions
router.post('/getmail', forgotPassController.getmail);
router.get('/resetpassword/:id', forgotPassController.resetpassword);
router.get('/updatepassword/:resetpasswordid', forgotPassController.updatepassword);

module.exports = router;

const forgotbtn = document.getElementById('forgotbtn');
forgotbtn.addEventListener('click', postmail);

async function postmail(e) {
  try {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const detail = {
      email: email
    };

    const res = await axios.post('http://localhost:3000/password/forgotpassword', detail);
    if (res.status === 200) {
      alert(res.data.message);
    } else {
      alert('Error');
    }
  } catch (err) {
    if (err.response) {
      alert(err.response.data.message);
      console.log(err);
    } else {
      alert('Error');
    }
  }
}